import {
  FormInput,
  IDate,
  InputType,
  IText,
  MaxLength,
} from 'ngx-input-annotations';

export default class MultilanguageForm {
  constructor() {}

  @MaxLength(10)
  @FormInput({
    type: InputType.TEXT,
    metadata: {
      label: 'First name',
      placeholder: 'Enter first name',
    },
  })
  firstNameMl: IText;

  @FormInput({
    type: InputType.TEXT,
    metadata: {
      label: 'Last name',
      placeholder: 'Enter last name',
    },
  })
  lastNameMl: IText;

  @FormInput({
    type: InputType.DATE,
    metadata: {
      label: 'Date',
      placeholder: 'Date of creation',
    },
  })
  dateMl: IDate;
}
