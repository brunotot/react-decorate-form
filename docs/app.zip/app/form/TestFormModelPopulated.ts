import {
  MinLength,
  Required,
  FormInput,
  Validator,
  InputType,
  Email,
  IChips,
  ISearch,
  ITel,
  IColor,
} from 'ngx-input-annotations';

export interface ITestFormModelPopulated {
  username?: string;
  password?: string;
  confirmPassword?: string;
  email?: string;
  chips?: string[] | undefined;
  isHuman?: boolean;
  gender?: string[];
  description?: string;
  age?: number;
  date?: number | Date;
  url?: string;
  search?: string | undefined;
  tel?: string | undefined;
  color?: IColor;
}

export default class TestFormModelPopulated {
  constructor(o: ITestFormModelPopulated) {
    this.username = o.username;
    this.password = o.password;
    this.confirmPassword = o.confirmPassword;
    this.email = o.email;
    this.isHuman = o.isHuman;
    this.gender = o.gender;
    this.description = o.description;
    this.age = o.age;
    this.date = o.date;
    this.url = o.url;
    this.chips = o.chips;
    this.search = o.search;
    this.tel = o.tel;
    this.color = o.color;
  }

  hiddenNumber: number = 5;

  @Required()
  @MinLength(5)
  @FormInput({
    type: InputType.TEXT,
    metadata: {
      label: 'Username',
      placeholder: 'Enter username',
    },
  })
  username: string | undefined;

  @Required()
  @MinLength({ minLength: 5 })
  @FormInput({
    type: InputType.PASSWORD,
    metadata: {
      label: 'Password',
      placeholder: 'Enter password',
    },
  })
  password: string | undefined;

  @Validator({
    message: 'Passwords must match',
    isValid: (value: string, _this: TestFormModelPopulated) =>
      _this.password === value,
  })
  @FormInput({
    type: InputType.PASSWORD,
    metadata: {
      label: 'Confirm password',
      placeholder: 'Enter confirm password',
    },
  })
  confirmPassword: string | undefined;

  @FormInput({
    type: InputType.TEXTAREA,
    metadata: {
      label: 'Description',
      placeholder: 'Enter description',
    },
  })
  description: string | undefined;

  @FormInput({
    type: InputType.NUMBER,
    metadata: {
      label: 'Age',
      placeholder: 'Enter age',
    },
  })
  @Validator({
    message: 'You must be 18 or older',
    isValid: (value: number) => value >= 18,
  })
  age: number | undefined;

  @Required()
  @FormInput({
    type: InputType.DATE,
    metadata: {
      label: 'Date',
      placeholder: 'Enter date',
      hint: 'MM/DD/YYYY',
    },
  })
  date: Date | number | undefined;

  @Required()
  @Email()
  @FormInput({
    type: InputType.EMAIL,
    metadata: {
      label: 'Email',
      placeholder: 'Enter email',
      hint: 'john.doe@gmail.com',
    },
  })
  email: string | undefined;

  @Required()
  @FormInput({
    type: InputType.SELECT,
    metadata: {
      label: 'Gender',
      placeholder: 'Choose',
      multiple: true,
      items: [
        { id: 'M', text: 'Male' },
        { id: 'F', text: 'Female' },
        { id: 'O', text: 'Other' },
      ],
    },
  })
  gender: string[] | undefined;

  @Required()
  @FormInput({
    type: InputType.CHECKBOX,
    metadata: {
      label: 'Human',
    },
  })
  isHuman: boolean | undefined;

  @Required()
  @MinLength(5)
  @FormInput({
    type: InputType.URL,
    metadata: {
      label: 'URL',
      placeholder: 'Enter URL',
    },
  })
  url: string | undefined;

  @FormInput({
    type: InputType.CHIPS,
    metadata: {
      label: 'Chips',
      placeholder: 'Start typing...',
    },
  })
  chips: IChips;

  @FormInput({
    type: InputType.SEARCH,
    metadata: {
      label: 'Search',
      placeholder: 'Search :)',
    },
  })
  search: ISearch;

  @FormInput({
    type: InputType.TEL,
    metadata: {
      label: 'Telephone',
      placeholder: 'Numbers only',
    },
  })
  tel: ITel;

  @FormInput({
    type: InputType.COLOR,
    metadata: {
      label: 'Color',
    },
  })
  color: IColor;

  /*@FormInput({
    type: InputType.RANGE,
    metadata: {
      label: 'Range',
      min: 2000,
      max: 10000,
    },
  })
  @Validator({
    message: 'Must be above 8000',
    isValid: (value: number) => value > 8000,
  })
  range!: number;

  @Required()
  @FormInput({
    type: InputType.CHIPS,
    metadata: {
      label: 'Chips',
      placeholder: 'Start typing...',
      hint: 'This is a hint',
    },
  })
  chips!: string[];*/
}
