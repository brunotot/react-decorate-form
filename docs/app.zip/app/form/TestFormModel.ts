import {
  MinLength,
  Required,
  FormInput,
  Validator,
  InputType,
  Email,
  IMultilanguage,
  IText,
  IPassword,
  ITextArea,
  INumber,
  IDate,
  IEmail,
  ISelect,
  ISearch,
  ICheckbox,
  IColor,
  ITel,
  IURL,
} from 'ngx-input-annotations';
import MultilanguageForm from './MultilanguageForm';

export default class TestFormModel {
  constructor() {}

  hiddenNumber: number = 5;

  @Required()
  @MinLength(5)
  @FormInput({
    type: InputType.TEXT,
    metadata: {
      label: 'Username',
      placeholder: 'Enter username',
    },
  })
  username: IText;

  @Required()
  @MinLength({ minLength: 5 })
  @FormInput({
    type: InputType.PASSWORD,
    metadata: {
      label: 'Password',
      placeholder: 'Enter password',
    },
  })
  password: IPassword;

  @Validator({
    message: 'Passwords must match',
    isValid: (value: string, _this: TestFormModel) => _this.password === value,
  })
  @FormInput({
    type: InputType.PASSWORD,
    metadata: {
      label: 'Confirm password',
      placeholder: 'Enter confirm password',
    },
  })
  confirmPassword!: IPassword;

  @FormInput({
    type: InputType.TEXTAREA,
    metadata: {
      label: 'Description',
      placeholder: 'Enter description',
    },
  })
  description: ITextArea;

  @FormInput({
    type: InputType.NUMBER,
    metadata: {
      label: 'Age',
      placeholder: 'Enter age',
    },
  })
  @Validator({
    message: 'You must be 18 or older',
    isValid: (value: number) => value >= 18,
  })
  age: INumber;

  @Required()
  @FormInput({
    type: InputType.DATE,
    metadata: {
      label: 'Date',
      placeholder: 'Enter date',
      hint: 'MM/DD/YYYY',
    },
  })
  date: IDate;

  @Required()
  @Email()
  @FormInput({
    type: InputType.EMAIL,
    metadata: {
      label: 'Email',
      placeholder: 'Enter email',
      hint: 'john.doe@gmail.com',
    },
  })
  email: IEmail;

  @Required()
  @FormInput({
    type: InputType.SELECT,
    metadata: {
      label: 'Gender',
      placeholder: 'Choose',
      items: [
        { id: 'M', text: 'Male' },
        { id: 'F', text: 'Female' },
        { id: 'O', text: 'Other' },
      ],
    },
  })
  gender: ISelect;

  @Required()
  @FormInput({
    type: InputType.SEARCH,
    metadata: {
      label: 'Search',
      placeholder: 'Start typing...',
      hint: 'You should search here... :-)',
    },
  })
  search: ISearch;

  @Required()
  @FormInput({
    type: InputType.CHECKBOX,
    metadata: {
      label: 'Human',
    },
  })
  isHuman: ICheckbox;

  @Required()
  @FormInput({
    type: InputType.MULTILANGUAGE,
    metadata: {
      label: 'Multilanguage',
      languages: ['hr', 'de', 'eng', 'ja', 'it', 'cz'],
      formClass: MultilanguageForm,
    },
  })
  multilanguage: IMultilanguage;

  @Required()
  @FormInput({
    type: InputType.COLOR,
    metadata: {
      label: 'Color',
    },
  })
  color: IColor;

  @Required()
  @FormInput({
    type: InputType.TEL,
    metadata: {
      label: 'Tel',
    },
  })
  tel: ITel;

  @Required()
  @FormInput({
    type: InputType.URL,
    metadata: {
      label: 'URL',
    },
  })
  url: IURL;
}
