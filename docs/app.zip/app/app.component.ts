import { Component, OnInit } from '@angular/core';
import { IForm } from 'projects/ngx-rapid-interface-builder/src/form/base/BaseForm';
import { Form } from 'projects/ngx-rapid-interface-builder/src/form/Form';
import FormControlWrapper from 'projects/ngx-rapid-interface-builder/src/model/FormControlWrapper';
import Validators from 'projects/ngx-rapid-interface-builder/src/model/Validators';
import * as faker from 'faker';
import { IRGB } from 'projects/ngx-rapid-interface-builder/src/model/ValidatorBuilder';
import { RGBToHex } from 'projects/ngx-rapid-interface-builder/src/utility/ColorUtils';
import { IActionPermissions, ISave } from 'projects/ngx-rapid-interface-builder/src/type/DatatableConfig';
import { IColumnConfig } from 'projects/ngx-rapid-interface-builder/src/type/FormInputConfig';
import { getCompareFn, IAjax, IPaginationState } from 'projects/ngx-rapid-interface-builder/src/utility/InputEntityUtils';
import { database } from 'faker';

function getRandomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min) + min);
}

function generateRandomSelect2Data() {
  let select2Data: any = [];
  [...Array(getRandomInt(1, 50)).keys()].forEach(i => {
    let data: any = {};
    data.id = i + '';
    data.text = faker.name.findName();
    select2Data.push(data);
  })
  return select2Data;
}

function getRandomFormValues(): IForm[] {
  return [...Array(getRandomInt(100, 200)).keys()].map(i => generateRandomFormValue(`${i+1}`))
}

function getRandomTime(): string {
  let hh = `${getRandomInt(0, 23)}`.padStart(2, '0');
  let mm = `${getRandomInt(0, 59)}`.padStart(2, '0');
  return `${hh}:${mm}`
}

function getRandomColor(): string {
  let rgb: IRGB = {
    red: getRandomInt(0, 255),
    green: getRandomInt(0, 255),
    blue: getRandomInt(0, 255)
  }
  return RGBToHex(rgb);
}

function getRandomPhoneNumber(): string {
  return `+${getRandomInt(0, 999)}/${getRandomInt(0, 99)}-${getRandomInt(10000, 999999)}`
}

function getRandomWeek(): string {
  return `${getRandomInt(1980, 3000)}-W${getRandomInt(10, 53)}`
}

function generateRandomFormValue(id: string): IForm {
  return {
    id,
    text: faker.name.findName(),
    date: faker.date.soon(),
    datetime: faker.date.past(),
    month: faker.date.recent(),
    time: getRandomTime(),
    number: getRandomInt(0, 500),
    textarea: faker.lorem.words(15),
    password: faker.animal.bear(),
    email: `${faker.name.firstName()}@mail.com`,
    color: getRandomColor(),
    checkbox: getRandomInt(0, 2) === 1,
    url: `http://www.${faker.name.firstName()}x.html`,
    search: faker.animal.cow(),
    phone: getRandomPhoneNumber(),
    range: getRandomInt(10000, 200000),
    week: getRandomWeek(),
    select2Single: "1",
    select2Multiple: ["1", "2"]
  }
}

let exampleFormValue: IForm = {
  id: "1",
  text: 'Thiasddsas',
  date: new Date("2025-07-01"),
  datetime: new Date("2025-07-01"),
  month: new Date("2025-07-01"),
  time: '03:20',
  number: 11,
  textarea: 'This is a text area example',
  password: 'password-example',
  email: 'test@test.com',
  color: '#000000',
  search: 'test',
  checkbox: false,
  url: 'http://www.example.com/index.html',
  phone: '+123/45-67890',
  week: '2021-W01',
  range: 60000,
  select2Multiple: ["1", "2"],
  select2Single: "1"
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  randomFormValues: IForm[] = [];

  actionPermissions: IActionPermissions = {
    create: true,
    read: true,
    update: true,
    delete: true
  }

  // Optional ajax
  ajax: IAjax = {
    loadData: async (paginationState, displayConfigsByFormControlName) => {
      let { searchFilter, currentPageNumber, entriesPerPage, sortingFormControlName, sortingType } = paginationState
      let formControlNames = Object.keys(displayConfigsByFormControlName);
      return new Promise(resolve => {
        setTimeout(() => {
          let searchFilterLowercase = searchFilter.toLowerCase();
          let filteredArray = this.randomFormValues.filter(item => {
            for (let formControlName of formControlNames) {
              let value = item[formControlName];
              let displayConfig = displayConfigsByFormControlName[formControlName];
              let inputEntity = displayConfig.inputEntity;
              let readValue = inputEntity.convertToDatatableValueReadOnly(value, displayConfig);
              let readValueLowercase = readValue.toLowerCase();
              if (readValueLowercase.includes(searchFilterLowercase)) return true;
            }
            return false;
          })
          if (sortingFormControlName) {
            let displayConfig = displayConfigsByFormControlName[sortingFormControlName];
            let { inputEntity } = displayConfig;
            filteredArray.sort((a, b) => {
              let valueA = a[sortingFormControlName];
              let valueB = b[sortingFormControlName];
              let compareFn = getCompareFn(inputEntity, displayConfig, sortingType)
              return compareFn(valueA, valueB)
            })
          }
          let startIndex = (currentPageNumber - 1) * entriesPerPage;
          let endIndex = startIndex + entriesPerPage;
          resolve({
            data: filteredArray.slice(startIndex, endIndex),
            count: filteredArray.length
          });
        }, 2000)
      })
    },
    onDelete: value => {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          let randomNum = getRandomInt(1, 10);
          if (randomNum % 2 === 0) {
            resolve();
          } else {
            reject('Deletion failed :D')
          }
        }, 1000)
      })
    },
    onUpdate: value => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve(value)
        }, 1000) 
      })
    },
    onCreate: value => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve()
        }, 1000) 
      })
    }
  }

  // Optional columns configuration
  columns: IColumnConfig[] = [
    { formControlName: 'id', label: 'ID'},
    { formControlName: 'text', label: 'Text :D' },
    { formControlName: 'textarea', label: 'Text area :)'},
    { formControlName: 'datetime' },
    { formControlName: 'color', label: 'Color'},
    { formControlName: 'range', label: 'Range' }
  ]

  // Get display name cb
  getDisplayName = (value: IForm): string => value['text'] as string;

  // Define what happens on table save
  onSave: (saveData: ISave) => Promise<IForm[] | void> = (saveData: ISave) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        let randomNum = getRandomInt(1, 10);
        if (randomNum % 2 === 0) {
          let arr: IForm[] = saveData.created.concat(saveData.updated);
          resolve(arr);
        } else {
          reject('Some random error on backend')
        }
      }, 100)
    })
  }

  // Define form configuration
  formControlWrapper: FormControlWrapper = new FormControlWrapper()
    .withHidden('id', 'ID')
    .withText({
      formControlName: 'text', 
      label: 'Text label',
      placeholder: 'Text placeholder',
      validatorConfigs: [
        Validators.required('Text required!'),
        {message: 'At least 5 characters required!', isValid: v => v.length >= 5}
      ]
    })
    .withColor({
      formControlName: 'color', 
      label: 'Color label',
      validatorConfigs: [{message: 'Red has to be 0', isValid: c => c.rgb?.red === 0}]
    })
    .withDateTime({
      formControlName: 'datetime',
      label: 'Datetime label',
      validatorConfigs: [
        Validators.required('Datetime required!'),
        {message: 'Year must be 2022 or above', isValid: d => d.getFullYear() >= 2022}
      ]
    })
    .withDate({
      formControlName: 'date', 
      label: 'Date label',
      validatorConfigs: [
        Validators.required('Date required!'), 
        {message: 'Date year must be above 2023', isValid: d => d.getFullYear() > 2023}
      ]
    })
    .withMonth({
      formControlName: 'month', 
      label: 'Month label',
      validatorConfigs: [
        Validators.required('Month required!'),
        {message: 'Month must be greater than April', isValid: d => (d as Date).getMonth() > 3}
      ]
    })
    .withTime({
      formControlName: 'time', 
      label: 'Time label',
      validatorConfigs: [
        Validators.required('Time required!'),
        {message: 'HH should be less than 4', isValid: t => t.hh < 4}
      ]
    })
    .withNumber({
      formControlName: 'number', 
      label: 'Number label',
      placeholder: 'Number placeholder',
      validatorConfigs: [
        Validators.required('Number required!'), 
        {message: 'Number should be greater than 10', isValid: v => v > 10}
      ]
    })
    .withTextArea({
      formControlName: 'textarea', 
      label: 'Textarea label',
      placeholder: 'Textarea placeholder',
      validatorConfigs: [Validators.required('Textarea required!')]
    })
    .withPassword({
      formControlName: 'password', 
      label: 'Password label',
      placeholder: 'Password placeholder',
      validatorConfigs: [Validators.required('Password required!')]
    })
    .withEmail({
      formControlName: 'email', 
      label: 'Email label',
      placeholder: 'Email placeholder',
      validatorConfigs: [Validators.required('Email required!')]
    })
    .withSearch({
      formControlName: 'search', 
      label: 'Search label',
      validatorConfigs: [Validators.required('Search required!')]
    })
    .withUrl({
      formControlName: 'url', 
      label: 'URL label',
      placeholder: 'URL placeholder',
      validatorConfigs: [Validators.required('Url required!')]
    })
    .withCheckbox({
      formControlName: 'checkbox', 
      validatorConfigs: [{message: 'Checkbox must be false', isValid: c => !c}],
      label: 'Checkbox label'
    })
    .withWeek({
      formControlName: 'week', 
      label: 'Week label',
      validatorConfigs: [
        Validators.required('Week required!'),
        {message: 'Week must be 1', isValid: w => w.week === 1}
      ]
    })
    .withPhone({
      formControlName: 'phone', 
      label: 'Phone label',
      placeholder: 'Phone placeholder',
      validatorConfigs: [Validators.required('Phone required!')]
    })
    .withRange({
      formControlName: 'range', 
      label: 'Range label',
      min: 10000,
      max: 200000,
      validatorConfigs: [Validators.min(50000, 'You have to be at least 50000 years old!')]
    })
    .withFileSingle({
      formControlName: 'file', 
      label: 'File label',
      validatorConfigs: [Validators.required('File required!')]
    })
    .withFileMultiple({
      formControlName: 'files', 
      multiple: true,
      label: 'Files multiple label',
      validatorConfigs: [
        Validators.required('Files multiple required!'),
        {message: 'There should be only one file', isValid: files => files?.length === 1}
      ]
    })
    .withSelectSingle({
      formControlName: 'select2Single', 
      label: 'Select2 single label',
      placeholder: 'Select2 single placeholder',
      data: [
        {id: '1', text: 'Option1'},
        {id: '2', text: 'Option2'},
        {id: '3', text: 'Option3'}
      ],
      validatorConfigs: [Validators.required('Select2 single required!')]
    })
    .withSelectMultiple({
      formControlName: 'select2Multiple', 
      label: 'Select2 multiple label',
      placeholder: 'Select2 multiple placeholder',
      data: [
        {id: '1', text: 'Option1'},
        {id: '2', text: 'Option2'},
        {id: '3', text: 'Option3'}
      ],
      validatorConfigs: [
        Validators.required('Select2 multiple required!'),
        {message: 'Select must have exactly 1 value', isValid: res => res.length === 1}
      ]
    })
    .buildInitialControls();


  // Define optional form title
  formTitle: string = 'Example title';

  // Define what happens on form submit
  onSubmitFn = (formValue: IForm): any => console.log(formValue)

  ngOnInit() {
    this.randomFormValues = getRandomFormValues();
  }
}
