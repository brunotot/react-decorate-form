import { Component, ViewEncapsulation } from '@angular/core';
import TestFormModel from './form/TestFormModel';
import TestFormModelPopulated from './form/TestFormModelPopulated';
import { faker } from '@faker-js/faker';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AppComponent {
  title = 'ngx-input-annotations-demo';

  formClass: any = TestFormModelPopulated;
  data: TestFormModelPopulated[];

  constructor() {
    this.data = [];
    Array.from({ length: 20 }).forEach(() => {
      let model = this.getRandomFormModel();
      this.data.push(model);
    });
  }

  model = new TestFormModel();
  //model = this.getRandomFormModel();

  getRandomFormModel(): TestFormModelPopulated {
    let password = faker.internet.password();
    return new TestFormModelPopulated({
      //username: faker.internet.userName(),
      color: randomGetOrUndefined(randomColor()),
      tel: randomGetOrUndefined(faker.random.numeric(9)),
      search: randomGetOrUndefined(faker.internet.userName()),
      username: getRandomValueFromArray([
        'username1',
        'username2',
        'username3',
        'username4',
      ]) as string,
      chips: randomGetOrUndefined(
        getRandomValueFromArray(
          [
            faker.internet.userName(),
            faker.internet.userName(),
            faker.internet.userName(),
          ],
          getRandomValueFromArray([1, 2, 3]) as number,
          true
        )
      ),
      password: randomGetOrUndefined(password),
      confirmPassword: randomGetOrUndefined(password),
      age: randomGetOrUndefined(Number(faker.random.numeric(2))),
      date: randomGetOrUndefined(faker.date.past()),
      description: randomGetOrUndefined(faker.lorem.lines()),
      email: randomGetOrUndefined(faker.internet.email()),
      url: randomGetOrUndefined(faker.internet.url()),
      gender: randomGetOrUndefined(
        getRandomValueFromArray(
          ['M', 'F', 'O'],
          getRandomValueFromArray([1, 2, 3]) as number,
          true
        )
      ),
      isHuman: randomGetOrUndefined(getRandomValueFromArray([true, false])),
    });
  }

  onSubmit(data: any) {
    console.log(data);
  }
}

function randomColor() {
  let value = Math.floor(Math.random() * 16777215).toString(16);
  return `#${value}`;
}

function randomGetOrUndefined(getValue: any): any | undefined {
  let shouldGet: boolean = getRandomValueFromArray([
    true,
    true,
    true,
    false,
  ]) as boolean;
  //return getValue;
  return shouldGet ? getValue : undefined;
}

function getRandomValueFromArray<T>(
  array: T[],
  numberOfValues: number = 1,
  forceArray: boolean = false
): T | T[] {
  if (forceArray || numberOfValues > 1) {
    let newArr: any[] = [];
    for (let i = 0; i < numberOfValues; i++) {
      const index = Math.floor(Math.random() * array.length);
      let val = array[index];
      newArr.push(val);
      array.splice(index, 1);
    }
    return newArr;
  }
  const index = Math.floor(Math.random() * array.length);
  return array[index];
}
