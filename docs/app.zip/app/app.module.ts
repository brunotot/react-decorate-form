import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxInputAnnotationsModule } from 'ngx-input-annotations';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, NgxInputAnnotationsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
